#!/usr/bin/env python3
"""
MinIO gRPC Client
MinIO 对象存储客户端
"""

from typing import List, Dict, Optional
from .base_client import BaseGRPCClient
from .proto import minio_service_pb2, minio_service_pb2_grpc


class MinIOClient(BaseGRPCClient):
    """MinIO gRPC 客户端"""

    def __init__(self, host: str = 'localhost', port: int = 50051, user_id: Optional[str] = None,
                 lazy_connect: bool = True, enable_compression: bool = True, enable_retry: bool = True):
        """
        初始化 MinIO 客户端

        Args:
            host: 服务地址 (默认: localhost)
            port: 服务端口 (默认: 50051)
            user_id: 用户 ID
            lazy_connect: 延迟连接 (默认: True)
            enable_compression: 启用压缩 (默认: True)
            enable_retry: 启用重试 (默认: True)
        """
        super().__init__(host, port, user_id, lazy_connect, enable_compression, enable_retry)
    
    def _create_stub(self):
        """创建 MinIO service stub"""
        return minio_service_pb2_grpc.MinIOServiceStub(self.channel)
    
    def service_name(self) -> str:
        return "MinIO"
    
    def health_check(self, detailed: bool = True) -> Optional[Dict]:
        """健康检查"""
        try:
            self._ensure_connected()
            request = minio_service_pb2.MinIOHealthCheckRequest(detailed=detailed)
            response = self.stub.HealthCheck(request)
            
            print(f"✅ [MinIO] 服务状态: {response.status}")
            print(f"   健康: {response.healthy}")
            if response.details:
                print(f"   详细信息: {dict(response.details)}")
            
            return {
                'status': response.status,
                'healthy': response.healthy,
                'details': dict(response.details) if response.details else {}
            }
            
        except Exception as e:
            return self.handle_error(e, "健康检查")
    
    def create_bucket(self, bucket_name: str, organization_id: str = 'default-org',
                     region: str = 'us-east-1') -> Optional[Dict]:
        """创建存储桶"""
        try:
            self._ensure_connected()
            request = minio_service_pb2.CreateBucketRequest(
                bucket_name=bucket_name,
                user_id=self.user_id,
                organization_id=organization_id,
                region=region
            )
            
            response = self.stub.CreateBucket(request)
            
            if response.success:
                print(f"✅ [MinIO] 桶创建成功: {bucket_name}")
                return {
                    'success': True,
                    'bucket': response.bucket_info.name if response.bucket_info else bucket_name
                }
            else:
                print(f"⚠️  [MinIO] {response.message or response.error}")
                return None
            
        except Exception as e:
            return self.handle_error(e, "创建桶")

    def delete_bucket(self, bucket_name: str, force: bool = False) -> bool:
        """删除存储桶

        Args:
            bucket_name: 桶名称
            force: 强制删除（包括所有对象）

        Returns:
            bool: 成功返回 True，失败返回 False
        """
        try:
            self._ensure_connected()
            request = minio_service_pb2.DeleteBucketRequest(
                bucket_name=bucket_name,
                user_id=self.user_id,
                force=force
            )

            response = self.stub.DeleteBucket(request)

            if response.success:
                print(f"✅ [MinIO] 桶删除成功: {bucket_name}")
                if response.deleted_objects > 0:
                    print(f"   删除了 {response.deleted_objects} 个对象")
                return True
            else:
                print(f"⚠️  [MinIO] {response.message or response.error}")
                return False

        except Exception as e:
            self.handle_error(e, "删除桶")
            return False

    def list_buckets(self, organization_id: str = 'default-org') -> List[str]:
        """列出存储桶"""
        try:
            self._ensure_connected()
            request = minio_service_pb2.ListBucketsRequest(
                user_id=self.user_id,
                organization_id=organization_id
            )

            response = self.stub.ListBuckets(request)

            if response.success:
                bucket_names = [bucket.name for bucket in response.buckets]
                print(f"✅ [MinIO] 找到 {len(bucket_names)} 个桶")
                return bucket_names
            else:
                print(f"⚠️  [MinIO] {response.error}")
                return []

        except Exception as e:
            return self.handle_error(e, "列出桶") or []

    def bucket_exists(self, bucket_name: str) -> bool:
        """检查桶是否存在"""
        try:
            info = self.get_bucket_info(bucket_name)
            return info is not None
        except Exception:
            return False

    def get_bucket_info(self, bucket_name: str) -> Optional[Dict]:
        """获取桶信息"""
        try:
            self._ensure_connected()
            request = minio_service_pb2.GetBucketInfoRequest(
                bucket_name=bucket_name,
                user_id=self.user_id
            )

            response = self.stub.GetBucketInfo(request)

            if response.success and response.bucket_info:
                info = {
                    'name': response.bucket_info.name,
                    'owner_id': response.bucket_info.owner_id,
                    'organization_id': response.bucket_info.organization_id,
                    'region': response.bucket_info.region,
                    'size_bytes': response.bucket_info.size_bytes,
                    'object_count': response.bucket_info.object_count
                }
                return info
            else:
                print(f"⚠️  [MinIO] {response.error}")
                return None

        except Exception as e:
            return self.handle_error(e, "获取桶信息")

    def set_bucket_policy(self, bucket_name: str, policy: str) -> bool:
        """设置桶策略"""
        try:
            self._ensure_connected()
            request = minio_service_pb2.SetBucketPolicyRequest(
                bucket_name=bucket_name,
                user_id=self.user_id,
                policy_type=minio_service_pb2.BUCKET_POLICY_CUSTOM,
                custom_policy=policy
            )

            response = self.stub.SetBucketPolicy(request)

            if response.success:
                print(f"✅ [MinIO] 桶策略设置成功: {bucket_name}")
                return True
            else:
                print(f"⚠️  [MinIO] {response.error}")
                return False

        except Exception as e:
            self.handle_error(e, "设置桶策略")
            return False

    def get_bucket_policy(self, bucket_name: str) -> Optional[str]:
        """获取桶策略"""
        try:
            self._ensure_connected()
            request = minio_service_pb2.GetBucketPolicyRequest(
                bucket_name=bucket_name,
                user_id=self.user_id
            )

            response = self.stub.GetBucketPolicy(request)

            if response.success:
                return response.policy_json
            else:
                print(f"⚠️  [MinIO] {response.error}")
                return None

        except Exception as e:
            return self.handle_error(e, "获取桶策略")

    def delete_bucket_policy(self, bucket_name: str) -> bool:
        """删除桶策略"""
        # MinIO 通过设置空策略来删除
        return self.set_bucket_policy(bucket_name, "")

    # Bucket tags, versioning, and lifecycle methods
    def set_bucket_tags(self, bucket_name: str, tags: Dict[str, str]) -> bool:
        """设置桶标签"""
        try:
            self._ensure_connected()
            request = minio_service_pb2.SetBucketTagsRequest(
                bucket_name=bucket_name,
                user_id=self.user_id,
                tags=tags
            )

            response = self.stub.SetBucketTags(request)

            if response.success:
                print(f"✅ [MinIO] 桶标签设置成功: {bucket_name}")
                return True
            else:
                print(f"⚠️  [MinIO] {response.error}")
                return False

        except Exception as e:
            self.handle_error(e, "设置桶标签")
            return False

    def get_bucket_tags(self, bucket_name: str) -> Optional[Dict[str, str]]:
        """获取桶标签"""
        try:
            self._ensure_connected()
            request = minio_service_pb2.GetBucketTagsRequest(
                bucket_name=bucket_name,
                user_id=self.user_id
            )

            response = self.stub.GetBucketTags(request)

            if response.success:
                print(f"✅ [MinIO] 桶标签获取成功: {len(response.tags)} 个标签")
                return dict(response.tags)
            else:
                print(f"⚠️  [MinIO] {response.error}")
                return None

        except Exception as e:
            return self.handle_error(e, "获取桶标签")

    def delete_bucket_tags(self, bucket_name: str) -> bool:
        """删除桶标签"""
        try:
            self._ensure_connected()
            request = minio_service_pb2.DeleteBucketTagsRequest(
                bucket_name=bucket_name,
                user_id=self.user_id
            )

            response = self.stub.DeleteBucketTags(request)

            if response.success:
                print(f"✅ [MinIO] 桶标签删除成功: {bucket_name}")
                return True
            else:
                print(f"⚠️  [MinIO] {response.error}")
                return False

        except Exception as e:
            self.handle_error(e, "删除桶标签")
            return False

    def set_bucket_versioning(self, bucket_name: str, enabled: bool) -> bool:
        """设置桶版本控制"""
        try:
            self._ensure_connected()
            request = minio_service_pb2.SetBucketVersioningRequest(
                bucket_name=bucket_name,
                user_id=self.user_id,
                enabled=enabled
            )

            response = self.stub.SetBucketVersioning(request)

            if response.success:
                status = "启用" if enabled else "禁用"
                print(f"✅ [MinIO] 桶版本控制{status}成功: {bucket_name}")
                return True
            else:
                print(f"⚠️  [MinIO] {response.error}")
                return False

        except Exception as e:
            self.handle_error(e, "设置桶版本控制")
            return False

    def get_bucket_versioning(self, bucket_name: str) -> bool:
        """获取桶版本控制状态"""
        try:
            self._ensure_connected()
            request = minio_service_pb2.GetBucketVersioningRequest(
                bucket_name=bucket_name,
                user_id=self.user_id
            )

            response = self.stub.GetBucketVersioning(request)

            if response.success:
                status = "启用" if response.enabled else "禁用"
                print(f"✅ [MinIO] 桶版本控制状态: {status}")
                return response.enabled
            else:
                print(f"⚠️  [MinIO] {response.error}")
                return False

        except Exception as e:
            self.handle_error(e, "获取桶版本控制状态")
            return False

    def set_bucket_lifecycle(self, bucket_name: str, rules: List[Dict]) -> bool:
        """设置桶生命周期策略"""
        try:
            self._ensure_connected()
            from google.protobuf import struct_pb2

            # Convert rules to protobuf LifecycleRule objects
            lifecycle_rules = []
            for rule in rules:
                # Create LifecycleRule protobuf message
                lifecycle_rule = minio_service_pb2.LifecycleRule()
                lifecycle_rule.id = rule.get('id', '')
                lifecycle_rule.status = rule.get('status', 'Enabled')

                # Convert nested dicts to Struct objects
                if 'filter' in rule and rule['filter']:
                    lifecycle_rule.filter.update(rule['filter'])
                if 'expiration' in rule and rule['expiration']:
                    lifecycle_rule.expiration.update(rule['expiration'])
                if 'transition' in rule and rule['transition']:
                    lifecycle_rule.transition.update(rule['transition'])

                lifecycle_rules.append(lifecycle_rule)

            request = minio_service_pb2.SetBucketLifecycleRequest(
                bucket_name=bucket_name,
                user_id=self.user_id,
                rules=lifecycle_rules
            )

            response = self.stub.SetBucketLifecycle(request)

            if response.success:
                print(f"✅ [MinIO] 桶生命周期策略设置成功: {bucket_name}")
                return True
            else:
                print(f"⚠️  [MinIO] {response.error}")
                return False

        except Exception as e:
            self.handle_error(e, "设置桶生命周期策略")
            return False

    def get_bucket_lifecycle(self, bucket_name: str) -> Optional[List[Dict]]:
        """获取桶生命周期策略"""
        try:
            self._ensure_connected()
            request = minio_service_pb2.GetBucketLifecycleRequest(
                bucket_name=bucket_name,
                user_id=self.user_id
            )

            response = self.stub.GetBucketLifecycle(request)

            if response.success:
                from google.protobuf.json_format import MessageToDict
                rules = [MessageToDict(rule) for rule in response.rules]
                print(f"✅ [MinIO] 桶生命周期策略获取成功: {len(rules)} 条规则")
                return rules
            else:
                print(f"⚠️  [MinIO] {response.error}")
                return None

        except Exception as e:
            return self.handle_error(e, "获取桶生命周期策略")

    def delete_bucket_lifecycle(self, bucket_name: str) -> bool:
        """删除桶生命周期策略"""
        try:
            self._ensure_connected()
            request = minio_service_pb2.DeleteBucketLifecycleRequest(
                bucket_name=bucket_name,
                user_id=self.user_id
            )

            response = self.stub.DeleteBucketLifecycle(request)

            if response.success:
                print(f"✅ [MinIO] 桶生命周期策略删除成功: {bucket_name}")
                return True
            else:
                print(f"⚠️  [MinIO] {response.error}")
                return False

        except Exception as e:
            self.handle_error(e, "删除桶生命周期策略")
            return False
    
    def upload_object(self, bucket_name: str, object_key: str, data: bytes,
                     content_type: str = 'application/octet-stream', metadata: Optional[Dict[str, str]] = None) -> Optional[Dict]:
        """上传对象 (流式)"""
        try:
            self._ensure_connected()
            def request_generator():
                # 第一个消息：元数据
                meta = minio_service_pb2.PutObjectMetadata(
                    bucket_name=bucket_name,
                    object_key=object_key,
                    user_id=self.user_id,
                    content_type=content_type,
                    content_length=len(data)
                )
                if metadata:
                    meta.metadata.update(metadata)
                yield minio_service_pb2.PutObjectRequest(metadata=meta)

                # 后续消息：数据块
                chunk_size = 1024 * 64  # 64KB chunks
                for i in range(0, len(data), chunk_size):
                    chunk = data[i:i + chunk_size]
                    yield minio_service_pb2.PutObjectRequest(chunk=chunk)

            response = self.stub.PutObject(request_generator())

            if response.success:
                print(f"✅ [MinIO] 对象上传成功: {object_key}")
                return {
                    'success': True,
                    'object_key': response.object_key,
                    'size': response.size,
                    'etag': response.etag
                }
            else:
                print(f"⚠️  [MinIO] {response.error}")
                return None

        except Exception as e:
            return self.handle_error(e, "上传对象")
    
    def list_objects(self, bucket_name: str, prefix: str = '', max_keys: int = 100) -> List[Dict]:
        """列出对象"""
        try:
            self._ensure_connected()
            request = minio_service_pb2.ListObjectsRequest(
                bucket_name=bucket_name,
                user_id=self.user_id,
                prefix=prefix,
                max_keys=max_keys
            )

            response = self.stub.ListObjects(request)

            if response.success:
                objects = []
                for obj in response.objects:
                    objects.append({
                        'name': obj.key,  # Add 'name' alias for compatibility
                        'key': obj.key,
                        'size': obj.size,
                        'content_type': obj.content_type,
                        'etag': obj.etag
                    })
                print(f"✅ [MinIO] 找到 {len(objects)} 个对象")
                return objects
            else:
                print(f"⚠️  [MinIO] {response.error}")
                return []

        except Exception as e:
            return self.handle_error(e, "列出对象") or []

    def get_object(self, bucket_name: str, object_key: str) -> Optional[bytes]:
        """下载对象 (流式)"""
        try:
            self._ensure_connected()
            request = minio_service_pb2.GetObjectRequest(
                bucket_name=bucket_name,
                object_key=object_key,
                user_id=self.user_id
            )

            response_stream = self.stub.GetObject(request)
            data = bytearray()

            for response in response_stream:
                if response.HasField('metadata'):
                    # First response contains metadata
                    continue
                elif response.HasField('chunk'):
                    data.extend(response.chunk)

            print(f"✅ [MinIO] 对象下载成功: {object_key} ({len(data)} bytes)")
            return bytes(data)

        except Exception as e:
            return self.handle_error(e, "下载对象")

    def delete_object(self, bucket_name: str, object_key: str) -> bool:
        """删除对象"""
        try:
            self._ensure_connected()
            request = minio_service_pb2.DeleteObjectRequest(
                bucket_name=bucket_name,
                object_key=object_key,
                user_id=self.user_id
            )

            response = self.stub.DeleteObject(request)

            if response.success:
                print(f"✅ [MinIO] 对象删除成功: {object_key}")
                return True
            else:
                print(f"⚠️  [MinIO] {response.error}")
                return False

        except Exception as e:
            self.handle_error(e, "删除对象")
            return False

    def delete_objects(self, bucket_name: str, object_keys: List[str]) -> bool:
        """批量删除对象"""
        try:
            self._ensure_connected()
            request = minio_service_pb2.DeleteObjectsRequest(
                bucket_name=bucket_name,
                user_id=self.user_id,
                object_keys=object_keys,
                quiet=False
            )

            response = self.stub.DeleteObjects(request)

            if response.success:
                print(f"✅ [MinIO] 批量删除成功: {len(response.deleted_keys)} 个对象")
                return True
            else:
                print(f"⚠️  [MinIO] {response.error}")
                return False

        except Exception as e:
            self.handle_error(e, "批量删除对象")
            return False

    def copy_object(self, dest_bucket: str, dest_key: str, source_bucket: str, source_key: str) -> bool:
        """复制对象"""
        try:
            self._ensure_connected()
            request = minio_service_pb2.CopyObjectRequest(
                source_bucket=source_bucket,
                source_key=source_key,
                dest_bucket=dest_bucket,
                dest_key=dest_key,
                user_id=self.user_id
            )

            response = self.stub.CopyObject(request)

            if response.success:
                print(f"✅ [MinIO] 对象复制成功: {source_key} -> {dest_key}")
                return True
            else:
                print(f"⚠️  [MinIO] {response.error}")
                return False

        except Exception as e:
            self.handle_error(e, "复制对象")
            return False

    def get_object_metadata(self, bucket_name: str, object_key: str) -> Optional[Dict]:
        """获取对象元数据 (使用 StatObject)"""
        try:
            self._ensure_connected()
            request = minio_service_pb2.StatObjectRequest(
                bucket_name=bucket_name,
                object_key=object_key,
                user_id=self.user_id
            )

            response = self.stub.StatObject(request)

            if response.success and response.object_info:
                metadata = {
                    'key': response.object_info.key,
                    'size': response.object_info.size,
                    'etag': response.object_info.etag,
                    'content_type': response.object_info.content_type,
                    'last_modified': response.object_info.last_modified,
                    'metadata': dict(response.object_info.metadata) if response.object_info.metadata else {}
                }
                return metadata
            else:
                print(f"⚠️  [MinIO] {response.error}")
                return None

        except Exception as e:
            return self.handle_error(e, "获取对象元数据")

    # Convenience aliases for compatibility
    def put_object(self, bucket_name: str, object_key: str, data, size: int, metadata: Optional[Dict] = None) -> bool:
        """上传对象 (兼容性方法)"""
        import io
        if isinstance(data, io.BytesIO):
            data = data.read()
        elif not isinstance(data, bytes):
            data = bytes(data)

        result = self.upload_object(bucket_name, object_key, data, metadata=metadata or {})
        return result is not None

    def upload_file(self, bucket_name: str, object_key: str, file_path: str) -> bool:
        """从文件上传对象"""
        try:
            with open(file_path, 'rb') as f:
                data = f.read()
            result = self.upload_object(bucket_name, object_key, data)
            return result is not None
        except Exception as e:
            self.handle_error(e, "从文件上传对象")
            return False

    # Object tags methods
    def set_object_tags(self, bucket_name: str, object_key: str, tags: Dict[str, str]) -> bool:
        """设置对象标签"""
        try:
            self._ensure_connected()
            request = minio_service_pb2.SetObjectTagsRequest(
                bucket_name=bucket_name,
                object_key=object_key,
                user_id=self.user_id,
                tags=tags
            )

            response = self.stub.SetObjectTags(request)

            if response.success:
                print(f"✅ [MinIO] 对象标签设置成功: {object_key}")
                return True
            else:
                print(f"⚠️  [MinIO] {response.error}")
                return False

        except Exception as e:
            self.handle_error(e, "设置对象标签")
            return False

    def get_object_tags(self, bucket_name: str, object_key: str) -> Optional[Dict[str, str]]:
        """获取对象标签"""
        try:
            self._ensure_connected()
            request = minio_service_pb2.GetObjectTagsRequest(
                bucket_name=bucket_name,
                object_key=object_key,
                user_id=self.user_id
            )

            response = self.stub.GetObjectTags(request)

            if response.success:
                print(f"✅ [MinIO] 对象标签获取成功: {len(response.tags)} 个标签")
                return dict(response.tags)
            else:
                print(f"⚠️  [MinIO] {response.error}")
                return None

        except Exception as e:
            return self.handle_error(e, "获取对象标签")

    def delete_object_tags(self, bucket_name: str, object_key: str) -> bool:
        """删除对象标签"""
        try:
            self._ensure_connected()
            request = minio_service_pb2.DeleteObjectTagsRequest(
                bucket_name=bucket_name,
                object_key=object_key,
                user_id=self.user_id
            )

            response = self.stub.DeleteObjectTags(request)

            if response.success:
                print(f"✅ [MinIO] 对象标签删除成功: {object_key}")
                return True
            else:
                print(f"⚠️  [MinIO] {response.error}")
                return False

        except Exception as e:
            self.handle_error(e, "删除对象标签")
            return False

    def list_object_versions(self, bucket_name: str, object_key: str) -> Optional[List[Dict]]:
        """列出对象版本 (暂未实现)"""
        print(f"⚠️  [MinIO] list_object_versions not implemented in proto service")
        return None
    
    def get_presigned_url(self, bucket_name: str, object_key: str,
                         expiry_seconds: int = 3600) -> Optional[str]:
        """获取预签名 URL (GET)"""
        try:
            self._ensure_connected()
            request = minio_service_pb2.GetPresignedURLRequest(
                bucket_name=bucket_name,
                object_key=object_key,
                user_id=self.user_id,
                expiry_seconds=expiry_seconds
            )

            response = self.stub.GetPresignedURL(request)

            if response.success:
                print(f"✅ [MinIO] 预签名 URL 生成成功")
                return response.url
            else:
                print(f"⚠️  [MinIO] {response.error}")
                return None

        except Exception as e:
            return self.handle_error(e, "获取预签名 URL")

    def get_presigned_put_url(self, bucket_name: str, object_key: str,
                              expiry_seconds: int = 3600, content_type: str = 'application/octet-stream') -> Optional[str]:
        """获取预签名 URL (PUT)"""
        try:
            self._ensure_connected()
            request = minio_service_pb2.GetPresignedPutURLRequest(
                bucket_name=bucket_name,
                object_key=object_key,
                user_id=self.user_id,
                expiry_seconds=expiry_seconds,
                content_type=content_type
            )

            response = self.stub.GetPresignedPutURL(request)

            if response.success:
                print(f"✅ [MinIO] 预签名 PUT URL 生成成功")
                return response.url
            else:
                print(f"⚠️  [MinIO] {response.error}")
                return None

        except Exception as e:
            return self.handle_error(e, "获取预签名 PUT URL")

    def generate_presigned_url(self, bucket_name: str, object_key: str,
                               expiry_seconds: int = 3600, method: str = 'GET') -> Optional[str]:
        """生成预签名 URL (兼容性方法)"""
        if method.upper() == 'PUT':
            return self.get_presigned_put_url(bucket_name, object_key, expiry_seconds)
        else:
            return self.get_presigned_url(bucket_name, object_key, expiry_seconds)


# 便捷使用示例
if __name__ == '__main__':
    with MinIOClient(host='localhost', port=50051, user_id='test_user') as client:
        # 健康检查
        client.health_check()
        
        # 创建桶
        client.create_bucket('test-bucket')
        
        # 上传文件
        client.upload_object('test-bucket', 'test.txt', b'Hello MinIO!')
        
        # 列出对象
        objects = client.list_objects('test-bucket')
        print(f"对象: {objects}")

